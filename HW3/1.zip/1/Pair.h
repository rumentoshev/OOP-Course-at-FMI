#pragma once
#include <cstdint>
struct Pair
{
	bool isDef = false; //Think about it!!!
	int32_t result = 0;
};
