#pragma once
#include "PF.h"

class ExtrF : public PF
{

};