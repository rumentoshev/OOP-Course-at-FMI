#pragma once
#include <cstdint>

const int32_t MAX_ARGS_NUM = 32;
const size_t MAX_BUFFER_SIZE = 512;